<?php echo("Access Forbidden");exit(); ?>

<appml>

<database name="appmldemo">
<host>127.0.0.1</host>
<name>appmldemo</name>
<user>username</user>
<password>userpassword</password>
</database>

<database name="appmlsecurity">
<host>127.0.0.1</host>
<name>appmldemo</name>
<user>username</user>
<password>userpassword</password>
</database>

<dateformat>yyyy-mm-dd</dateformat>

</appml>